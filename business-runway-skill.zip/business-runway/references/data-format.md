# Data format

The same fields are used on every route. Route A writes them to the artifact database. Routes B and C put them in `business-runway-import.json`.

## Ids

Lowercase letters, numbers and dashes. Start with a letter or number. Max 120 characters. Receipts use date plus vendor, like `2026-09-02-print-shop`. Keep the same id when the same receipt comes again, so nothing is counted twice.

## settings/config

One document. In the import file it is the `config` object.

- `name`, `currency` (3 letters), `locale` (en-US, en-GB, de-DE, da-DK, sv-SE, nb-NO, fr-FR or nl-NL, matching how the user writes numbers)
- `vat` (percent), `reclaim` (true or false), `tax` (percent), `deal` (0 if skipped)
- `founders` (founders taking pay, at least 1)
- `start` (the day the business started, YYYY-MM-DD)
- `fx`: rates to the user's currency for every other currency they pay in, like `{"USD": 0.92}`. Say which rate you used and from which date. If you cannot look rates up, ask.

## subscriptions

One document per recurring cost: `name`, `what`, `amount` (ex VAT), `currency`, `cadence` (`month` or `year`), `vat` (true if VAT is added), `nextCharge` (YYYY-MM for yearly ones), `active` (true), `aliases` (other names the vendor uses on invoices), `kind`.

- the Claude plan: `kind` `software`, `name` "Claude", `what` the plan name, `cadence` as paid, `vat` true only if VAT is on the invoice
- each hire or freelancer: `kind` `salary`, `vat` false for employees, full monthly cost as `amount`. Name by role, never by name, like "Designer, part time". With one or two hires, suggest one line called "Team", because a role plus a salary can still point to one person
- rent: `kind` `rent`
- ads or marketing: `kind` `ads`
- everything else: `kind` `software` or `other`

## receivables

One document per unpaid invoice the user sent: `client`, `description`, `amountBase` (what lands in the bank, in the user's currency), `expectedDate` (YYYY-MM-DD), `paid` false.

## receipts

| field | what goes in it |
|---|---|
| `date` | invoice date, YYYY-MM-DD |
| `vendor` | who charged the user |
| `description` | what it was, short |
| `currency` | currency on the invoice |
| `amountOrig` | total on the invoice |
| `amountBase` | total in the user's currency, VAT included |
| `vatBase` | VAT in the user's currency, 0 if none |
| `category` | Software, Rent, Salary, Ads, Travel, Equipment, Food and drink, Other, or the user's own words |
| `status` | `business` when clearly a business cost, otherwise `open`. Never set `private` for the user |
| `needsDecision` | true when `status` is `open` |
| `paid` | true for card charges, false for bills still to pay |
| `dueDate` | for unpaid bills, YYYY-MM-DD |
| `source` | `email` or `photo` |
| `thumb` | Route A photos only: a small JPEG data URI, max 600 px wide and under 150 KB. Leave it out in Routes B and C |
| `hint` | one short line on why you were unsure |
| `addedAt` | now, ISO timestamp |

## questions

Anything you cannot decide: `order`, `question`, `detail`, and `options` as pairs like `[["business","Business"],["private","Private"]]`.

## settings/plan

Route A: never write it. The page owns it.
Routes B and C: only include `plan` if the user gave the numbers: `bank`, `drawNet`, `rev`, `step`, `revStart` (YYYY-MM), `drawStart` (YYYY-MM or "never").

## The import file (Routes B and C)

```json
{
  "format": "business-runway",
  "version": 1,
  "config": { "name": "Example Studio", "currency": "EUR", "locale": "en-GB", "vat": 25, "reclaim": true, "tax": 30, "founders": 1, "deal": 0, "start": "2026-01-15", "fx": { "USD": 0.92 } },
  "subscriptions": { "claude": { "name": "Claude", "what": "Pro", "amount": 18, "currency": "EUR", "cadence": "month", "vat": false, "active": true, "kind": "software" } },
  "receivables": { "inv-2026-014": { "client": "Client A", "description": "September work", "amountBase": 3000, "expectedDate": "2026-10-15", "paid": false } },
  "receipts": { "2026-09-02-print-shop": { "date": "2026-09-02", "vendor": "Print shop", "description": "Flyers", "currency": "EUR", "amountOrig": 125, "amountBase": 125, "vatBase": 25, "category": "Other", "status": "open", "needsDecision": true, "paid": true, "source": "email", "hint": "Could be private", "addedAt": "2026-09-17T10:00:00Z" } },
  "questions": {}
}
```

Every collection is an object keyed by id. The page checks the file before saving: it drops unknown shapes, text over 4000 characters, and anything that is not a real image in `thumb`. Files over 15 MB are refused.
