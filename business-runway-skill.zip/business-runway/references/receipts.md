# Receipts

Pick the part that matches the user's answers.

## Gmail and Google Drive

1. `assets/receipts-to-drive.gs` saves invoices from Gmail into a Drive folder by month, and sorts phone photos dropped into `_INBOX`.
2. Before they install it, explain what Google will ask for: read Gmail and add a label, create and move files in Drive. Google shows the Gmail part as full access. The script has no code that sends, forwards or deletes mail.
3. Walk them through the setup steps at the top of the script, one step at a time. Wait after each step. Make sure they check the time zone in Project Settings.
4. Very large inbox? Suggest `FIRST_RUN_DAYS` 90 or 30 for the first run.
5. Give them the script from `assets`. Never write your own version from memory.

Reading the receipts afterwards needs Claude access to their Drive or Gmail. If this Claude has no connector for it, they upload the PDFs to the chat.

## Outlook, OneDrive, Dropbox or other

There is no ready-made script in the kit. Offer two routes:

- Make, n8n or Zapier: describe a simple flow in plain steps. Trigger: new email with an attachment, filtered on words like invoice or receipt. Action: save the file into a month folder in their cloud storage. Say which connections it needs. Never ask for passwords or API keys in the chat.
- No automation: they forward or upload receipts to the chat when they say "update my runway".

## Paper receipts

Photograph each receipt and put the photo in the folder they picked in Round 4. File name `YYYY-MM-DD shop amount.jpg`, so the date is right even if they upload it later.
